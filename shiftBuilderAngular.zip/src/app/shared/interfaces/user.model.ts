export interface User {
  firstname: string;
  lastname: string;
  email: string;
  birthdate: string;
  password: string;
  passwordConfirm: string;
  uid: string;
  role: string;
  isDisabled: false;
}
    