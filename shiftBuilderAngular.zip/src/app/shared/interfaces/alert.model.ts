export interface Alert {
    title: string;
    content: string;
    messageType: string;
    isVisible: boolean;
    
  }
  